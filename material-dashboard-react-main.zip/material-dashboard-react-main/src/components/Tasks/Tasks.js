import { TableHead } from "@material-ui/core";
import IconButton from "@material-ui/core/IconButton";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableRow from "@material-ui/core/TableRow";
import Tooltip from "@material-ui/core/Tooltip";
import { Search } from "@material-ui/icons";
import Close from "@material-ui/icons/Close";
// @material-ui/icons
import Edit from "@material-ui/icons/Edit";
// core components
import styles from "assets/jss/material-dashboard-react/components/tasksStyle.js";
import classnames from "classnames";
import PropTypes from "prop-types";
import React from "react";

const useStyles = makeStyles(styles);

export default function Tasks(props) {
  const classes = useStyles();
  const { tasks, rtlActive, tableHead } = props;
  const tableCellClasses = classnames(classes.tableCell, {
    [classes.tableCellRTL]: rtlActive,
  });
  return (
    <Table className={classes.table}>
      <TableHead>
        <TableRow className={classes.tableHeadRow}>
          {tableHead.map((prop, key) => {
            return (
              <TableCell
                className={classes.tableCell + " " + classes.tableHeadCell}
                key={key}
              >
                {prop}
              </TableCell>
            );
          })}
        </TableRow>
      </TableHead>
      <TableBody>
        {tasks.map((value) => (
          <TableRow key={value} className={classes.tableRow}>
            <TableCell className={tableCellClasses}>{value.nom}</TableCell>
            <TableCell className={tableCellClasses}>{value.email}</TableCell>
            <TableCell className={tableCellClasses}>
              {value.dateInscription}
            </TableCell>
            <TableCell className={tableCellClasses}>
              {value.lastdateActif}
            </TableCell>
            <TableCell className={classes.tableActions}>
              <Tooltip
                id="tooltip-top"
                title="Modifier"
                placement="top"
                classes={{ tooltip: classes.tooltip }}
              >
                <IconButton
                  aria-label="Edit"
                  className={classes.tableActionButton}
                >
                  <Edit
                    className={
                      classes.tableActionButtonIcon + " " + classes.edit
                    }
                  />
                </IconButton>
              </Tooltip>
              <Tooltip
                id="tooltip-top-start"
                title="Rechercher"
                placement="top"
                classes={{ tooltip: classes.tooltip }}
              >
                <IconButton
                  aria-label="Search"
                  className={classes.tableActionButton}
                >
                  <Search
                    className={
                      classes.tableActionButtonIcon + " " + classes.close
                    }
                  />
                </IconButton>
              </Tooltip>
              <Tooltip
                id="tooltip-top-start"
                title="Supprimer"
                placement="top"
                classes={{ tooltip: classes.tooltip }}
              >
                <IconButton
                  aria-label="Close"
                  className={classes.tableActionButton}
                >
                  <Close
                    className={
                      classes.tableActionButtonIcon + " " + classes.close
                    }
                  />
                </IconButton>
              </Tooltip>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

Tasks.propTypes = {
  tasksIndexes: PropTypes.arrayOf(PropTypes.number),
  tasks: PropTypes.arrayOf(PropTypes.node),
  rtlActive: PropTypes.bool,
  checkedIndexes: PropTypes.array,
  tableHead: PropTypes.array,
};
