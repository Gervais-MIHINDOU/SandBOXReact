/*!

=========================================================
* Material Dashboard React - v1.10.0
=========================================================

* Product Page: https://www.creative-tim.com/product/material-dashboard-react
* Copyright 2021 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/material-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
// @material-ui/icons

import Notifications from "@material-ui/icons/Notifications";
import Person from "@material-ui/icons/Person";
import AdminProfile from "viewadmin/AdminProfile/AdminProfile";
import Clients from "viewadmin/Clients/Clients";
import Config from "viewadmin/Config/Config";
import Dashboard from "viewadmin/Dashboard/Dashboard";
import Notification from "viewutilisateur/Notification/Notification";
// core components/views for Admin layout

const routesAdmin = [
  {
    path: "/dashboard",
    name: "Tableau de bord",
    icon: Person,
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/clients",
    name: "Mes Clients",
    icon: Person,
    component: Clients,
    layout: "/admin",
  },
  {
    path: "/notifications",
    name: "Notifications",
    icon: Notifications,
    component: Notification,
    layout: "/admin",
  },
  {
    path: "/config",
    name: "Configuration",
    icon: Notifications,
    component: Config,
    layout: "/admin",
  },
  {
    path: "/user",
    name: "Mon compte Admin",
    icon: Notifications,
    component: AdminProfile,
    layout: "/admin",
  },
];

export default routesAdmin;
