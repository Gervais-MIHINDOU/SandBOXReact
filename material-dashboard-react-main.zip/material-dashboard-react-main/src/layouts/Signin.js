import { Avatar, Button, makeStyles, Typography } from "@material-ui/core";
import styles from "assets/jss/material-dashboard-react/components/sidebarStyle.js";
import baseIris, { firebaseApp } from "baseiris";
import firebase from "firebase";
import React, { useState } from "react";
//import irisLogo from "../img/logoiris.JPG";
import { Redirect } from "react-router-dom";
import googleLogo from "../img/google-logo.png";
import "./login.css";
import bgImage from "assets/img/sidebar-2.jpg";

const useStylesBackground = makeStyles(styles);

const useStyles = makeStyles((theme) => ({
  center: {
    display: "flex",
    justifyContent: "center",
  },
  button: {
    textTransform: "none",
    marginTop: theme.spacing(10),
    display: "flex",
    alignItems: "center",
    boxShadow: theme.shadows[3],
    backgroundColor: theme.palette.primary.main,
    color: theme.palette.primary.contrastText,
    transition: "background-color 0.5s",
    "&:hover": {
      backgroundColor: theme.palette.primary.dark,
      transition: "background-color 0.5s",
      cursor: "pointer",
    },
  },
  avatar: {
    margin: `0 ${theme.spacing(0.5)}px`,
  },
  text: {
    flexGrow: 1,
    textAlign: "center",
  },
  form: {
    position: "relative",
    zIndex: "2",
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

const SignIn = () => {
  const classes = useStyles();

  const classesBackgound = useStylesBackground();

  const style = {
    "font-size": "47px",
    "font-weight": "bold",
    "text-align": "center",
    color: "#3067E3",
  };

  const [client, setClient] = useState();
  const [goInAppClient, setGoInAppClient] = useState(false);

  const [goInAppAdmin, setGoInAppAdmin] = useState(false);

  const submit = (event) => {
    event.preventDefault();
    login();
  };

  const login = async () => {
    console.log("firebase debut");
    const googleProvider = new firebase.auth.GoogleAuthProvider();
    console.log("firebase fin");
    await firebaseApp.auth().signInWithPopup(googleProvider).then(handleAuth);
  };

  const handleAuth = async (authdata) => {
    const user = authdata.user;
    const client = { ...client };
    client["email"] = user.email;
    client["id"] = user.uid;
    client["nom"] = user.displayName;
    client["photo"] = user.photoURL;
    client["phone"] = user.phoneNumber;
    console.log(new Date().toISOString().split("T")[0]);
    setClient(client);
    const utilisateur = await baseIris.fetch(`/${client.id}`, {});
    if (!utilisateur.client) {
      client["dateInscription"] = new Date().toISOString().split("T")[0];
      baseIris.post(`/${user.uid}/client`, { data: client });
    }

    if (utilisateur?.client?.isAdmin) {
      setGoInAppAdmin(true);
    } else {
      setGoInAppClient(true);
    }
  };

  if (goInAppClient) {
    return <Redirect push to={`/client/${client.id}`} />;
  }

  if (goInAppAdmin) {
    return <Redirect push to={`/admin/${client.id}`} />;
  }

  return (
    <div className="connexionBox">
      <div className={classes.form}>
        <form className="connexion">
          <Typography style={style}>
            BIENVENUE <br />
            SUR <br />
            MY IRIS
          </Typography>

          <Button className={classes.button} onClick={submit}>
            <Avatar src={googleLogo} className={classes.avatar} />
            <Typography component="p" variant="h6" className={classes.text}>
              Connecter vous avec Google
            </Typography>
          </Button>
        </form>
      </div>

      <div
        className={classesBackgound.background}
        style={{ backgroundImage: "url(" + bgImage + ")" }}
      />
    </div>
  );
};

export default SignIn;
