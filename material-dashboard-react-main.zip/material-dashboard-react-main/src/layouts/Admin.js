// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import logo from "assets/img/reactlogo.png";
import bgImage from "assets/img/sidebar-2.jpg";
import styles from "assets/jss/material-dashboard-react/layouts/adminStyle.js";
import baseIris from "baseiris";
import Footer from "components/Footer/Footer.js";
// core components
import Navbar from "components/Navbars/Navbar.js";
import Sidebar from "components/Sidebar/Sidebar.js";
import firebase from "firebase";
// creates a beautiful scrollbar
import PerfectScrollbar from "perfect-scrollbar";
import "perfect-scrollbar/css/perfect-scrollbar.css";
import React, { useEffect, useState } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import routesAdmin from "routesadmin";
import AdminProfile from "viewadmin/AdminProfile/AdminProfile";
import Clients from "viewadmin/Clients/Clients";
import Config from "viewadmin/Config/Config";
import Dashboard from "viewadmin/Dashboard/Dashboard";
import Notification from "viewutilisateur/Notification/Notification";

let ps;

const useStyles = makeStyles(styles);

export default function Admin({ ...rest }) {
  const [admin, setAdmin] = useState();
  const [id, setid] = useState();

  const SwitchRoutes = () => (
    <Switch>
      <Route path={"/admin/dashboard"}>
        <Dashboard />
      </Route>
      <Route path="/admin/clients">
        <Clients />
      </Route>
      <Route path="/admin/config">
        <Config />
      </Route>
      <Route path={"/client/notifications"}>
        <Notification />
      </Route>
      <Route path="/client/user">
        <AdminProfile admin={admin} />
      </Route>
      <Redirect from="/admin" to={`/admin/dashboard`} />
    </Switch>
  );

  // styles
  const classes = useStyles();
  // ref to help us initialize PerfectScrollbar on windows devices
  const mainPanel = React.createRef();

  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  const resizeFunction = () => {
    if (window.innerWidth >= 960) {
      setMobileOpen(false);
    }
  };
  // initialize and destroy the PerfectScrollbar plugin
  React.useEffect(() => {
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(mainPanel.current, {
        suppressScrollX: true,
        suppressScrollY: false,
      });
      document.body.style.overflow = "hidden";
    }
    window.addEventListener("resize", resizeFunction);
    // Specify how to clean up after this effect:
    return function cleanup() {
      if (navigator.platform.indexOf("Win") > -1) {
        ps.destroy();
      }
      window.removeEventListener("resize", resizeFunction);
    };
  }, [mainPanel]);

  useEffect(() => {
    const reconnexion = async () => {
      await firebase.auth().onAuthStateChanged((user) => {
        // cette methode recupère uniquement le user du promise
        setid(user.uid);
      });
    };
    if (rest?.id) {
      setid(rest?.id);
    } else {
      reconnexion();
    }
  }, []);

  useEffect(() => {
    const user = async () => {
      const utilisateur = await baseIris.fetch(`/${id}`, {});
      const myAdmin = utilisateur.client;
      setAdmin({ ...admin, ...myAdmin });
    };
    user();
  }, [id]);

  return (
    <div className={classes.wrapper}>
      <Sidebar
        routes={routesAdmin}
        logoText={"Iris consulting"}
        logo={logo}
        image={bgImage}
        handleDrawerToggle={handleDrawerToggle}
        open={mobileOpen}
        color={"blue"}
        {...rest}
      />
      <div className={classes.mainPanel} ref={mainPanel}>
        <Navbar
          routes={routesAdmin}
          handleDrawerToggle={handleDrawerToggle}
          {...rest}
        />
        <div className={classes.content}>
          <div className={classes.container}>
            <SwitchRoutes />
          </div>
        </div>
        <Footer />
      </div>
    </div>
  );
}
