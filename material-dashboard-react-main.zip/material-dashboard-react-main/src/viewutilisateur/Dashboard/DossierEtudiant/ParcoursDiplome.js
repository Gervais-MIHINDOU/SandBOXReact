import { makeStyles, Typography } from "@material-ui/core";
import FormControl from "@material-ui/core/FormControl";
import baseIris from "baseiris";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import Button from "components/CustomButtons/Button.js";
import GridContainer from "components/Grid/GridContainer.js";
// core components
import GridItem from "components/Grid/GridItem.js";
import DialogFormation from "components/PopPup/DialogFormation";
import Table from "components/Table/Table.js";
import LinkFile, { sendFiles } from "gestionFichier";
import PropTypes from "prop-types";
import * as React from "react";

import ClearIcon from "@material-ui/icons/Clear";
import { removeDoc } from "gestionFichier";

const styles = {
  root: {
    flexGrow: 1,
  },
};

const useStyles = makeStyles(styles);

const ParcoursDiplome = ({ user, ajoutPropertie }) => {
  const filesFromFileStore = React.useRef([]);
  const filesFromDatabase = React.useRef({});

  const [formations, setformations] = React.useState({});

  const [formation, setFormation] = React.useState({});

  const [openDialog, setOpenDialog] = React.useState(false);
  const classes = useStyles();

  const [client, setClient] = React.useState();

  React.useEffect(() => {
    setClient({ ...client, ...user });
    setformations({ ...formations, ...user?.formations });
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    setOpenDialog(true);
  };

  const ajouterFormation = (event) => {
    event.preventDefault();
    setOpenDialog(false);

    const formationClient = { ...formation };
    formationClient["justificatifs_formation"] = filesFromDatabase.current;
    const formationsUPdated = { ...formations };
    formationsUPdated[formation.annee_scolaire] = formationClient;
    setformations(formationsUPdated);
    setFormation(formationClient);

    /** Modification du client */
    const clientUpdated = { ...user };
    clientUpdated["formations"] = formationsUPdated;
    clientUpdated["parcoursDiplomeOk"] = true;
    setClient(clientUpdated);
    baseIris.post(`/${client.id}/client`, { data: clientUpdated });

    /** Envoi des fichiers sur filestore */
    sendFiles(filesFromFileStore.current, "justificatifs_formation");

    /***Reinitialisation des fichiers */
    filesFromDatabase.current = {};
    filesFromFileStore.current = [];
    setFormation({});
    ajoutPropertie("parcoursDiplomeOk");
  };

  const annuler = (event) => {
    event.preventDefault();
    setOpenDialog(false);
    setFormation({});
  };

  const handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    formation[name] = value;
    setFormation(formation);
  };

  const deleteFormation = (event, annee) => {
    event.preventDefault();
    const formationClients = { ...formations };
    const clientUpdated = { ...user };
    suppressionFichierJustifsDeLaformation(formationClients[annee]);
    formationClients[annee] = null;
    clientUpdated["formations"] = formationClients;
    baseIris.update(`/${clientUpdated.id}/client`, { data: clientUpdated });
    setClient(clientUpdated);
    setformations(formationClients);
  };

  const suppressionFichierJustifsDeLaformation = (formation) => {
    Object.keys(formation["justificatifs_formation"]).map((id) => {
      removeDoc("justificatifs_formation" + "/" + id);
    });
  };

  const upload = (filesDatabase, filesFileStore) => {
    filesFromDatabase.current = filesDatabase;
    filesFromFileStore.current = filesFileStore;
  };

  const Option = () => {
    return (
      <GridContainer>
        <GridItem xs={12} sm={6} md={6}>
          <Typography variant="h7" component="div" align="center">
            Votre parcours doit comporter les 3 dernières années scolaires et
            activités à représentées par au moins un justificatif.
          </Typography>
        </GridItem>

        <GridItem xs={12} sm={6} md={6}>
          <FormControl fullWidth>
            <GridContainer>
              <GridItem xs={12} sm={12} md={12}>
                <Button color="info" onClick={handleSubmit} fullWidth>
                  AJOUTER UNE FORMATION
                </Button>
              </GridItem>
            </GridContainer>
          </FormControl>
        </GridItem>
      </GridContainer>
    );
  };

  const itemFormation = (formation) => {
    const justificatifs = formation["justificatifs_formation"];

    const a = [
      formation.annee_scolaire,
      formation.niveau,
      formation.etablissement,
      <ul key={formation.annee_scolaire}>{getJustifs(justificatifs)}</ul>,
      <ClearIcon
        color="secondary"
        onClick={(e) => deleteFormation(e, formation.annee_scolaire)}
        key={formation.annee_scolaire}
      />,
    ];
    return a;
  };

  const getJustifs = (justificatifs) => {
    if (!justificatifs) {
      return "";
    }
    console.log("Gervais les justif sont :");
    console.log(justificatifs);
    return Object.keys(justificatifs).map((item) => {
      if (!justificatifs[item]) {
        return "";
      }
      return (
        <li key={item}>
          <LinkFile
            item={item}
            nom={justificatifs[item]?.nom}
            nomCollection={"justificatifs_formation"}
          />
        </li>
      );
    });
  };

  const tabFormations = () => {
    const r = Object.keys(formations)
      .filter(function (annee) {
        console.log("La valeur de item est :" + annee);
        return (annee != null) & (formations[annee] != null);
      })
      .map((annee) => {
        console.log("La formation demandé est : ");
        console.log(formations[annee]);
        return itemFormation(formations[annee]);
      });
    return r;
  };

  return (
    <div className={classes.root}>
      <DialogFormation
        open={openDialog}
        title="Ajout d'une formation"
        ajouterFormation={ajouterFormation}
        annuler={annuler}
        handleChange={handleChange}
        formation={formation}
        upload={upload}
      />
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardBody>
              <Option />
              <Table
                tableHeaderColor="primary"
                tableHead={[
                  "Année",
                  "Niveau d'études",
                  "Etablissement",
                  "Justificatifs",
                ]}
                tableData={tabFormations()}
              />
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
    </div>
  );
};

export default ParcoursDiplome;
ParcoursDiplome.propTypes = {
  user: PropTypes.object,
  ajoutPropertie: PropTypes.func,
};
