import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import PropTypes from "prop-types";
import * as React from "react";
import ChoixPro from "./DossierEleve/ChoixPro";
import InfoEleve from "./DossierEleve/InfoEleve";
import ParcoursDiplome from "./DossierEtudiant/ParcoursDiplome";

const OrientationScolaire = ({ user }) => {
  const [load, setLoad] = React.useState();

  const ajoutPropertie = (propertieToLoad) => {
    user[propertieToLoad] = true;
    setLoad(!load);
  };

  const payementDossier = () => {
    if (user?.payementOrientationScolaireOk) {
      return "Le paiement a bien été effectué";
    } else {
      return "En attente de votre paiement";
    }
  };

  const irisVerifieDossier = () => {
    if (user?.verificationDossierOk) {
      return "Votre Dossier est complet et a été validé";
    } else {
      return "En attente de validation de la part d'iris";
    }
  };

  const style = {
    "font-size": "17px",
    "font-weight": "500",
  };

  const getStyleMessage = (ok) => {
    if (ok) {
      return { color: "#078041", "font-size": "15px", "font-weight": "550" };
    } else {
      return { color: "#EB2815", "font-size": "15px", "font-weight": "550" };
    }
  };

  return (
    <div>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={style}>{"1 - Information de l'élève"}</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <InfoEleve user={user} ajoutPropertie={ajoutPropertie} />
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography style={style}>{"2 - Parcours Scolaire"}</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <ParcoursDiplome user={user} ajoutPropertie={ajoutPropertie} />
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel3a-header"
        >
          <Typography style={style}>{"3 - Choix professionel"}</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <ChoixPro client={user} ajoutPropertie={ajoutPropertie} />
        </AccordionDetails>
      </Accordion>

      <Accordion
        disabled={
          !user?.dossierOk || !user?.parcoursDiplomeOk || !user?.choixProOK
        }
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography style={style}>2 - Iris vérifie mon dossier</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography
            variant="h10"
            style={getStyleMessage(user?.verificationDossierScolaireOk)}
          >
            {irisVerifieDossier()}
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion disabled={!user?.verificationDossierScolaireOk}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel3a-header"
        >
          <Typography style={style}>{"4 - Paiement"}</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography
            variant="h10"
            style={getStyleMessage(user?.payementOrientationScolaireOk)}
          >
            {payementDossier()}
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};

export default OrientationScolaire;
OrientationScolaire.propTypes = {
  user: PropTypes.object,
};
