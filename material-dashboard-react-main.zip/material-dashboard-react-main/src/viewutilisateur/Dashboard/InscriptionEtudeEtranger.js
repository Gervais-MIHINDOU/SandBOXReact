import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import PropTypes from "prop-types";
import * as React from "react";
import DossierUser from "./DossierEtudiant/DossierUser";

const InscriptionEtudeEtranger = ({ user }) => {
  const [load, setLoad] = React.useState();

  const ajoutPropertie = (propertieToLoad) => {
    user[propertieToLoad] = true;
    setLoad(!load);
  };

  const irisVerifieDossier = () => {
    if (user?.verificationDossierOk) {
      return "Votre Dossier est complet et a été validé. Vous pouvez procéder au paiement.";
    } else {
      return "En attente de validation de la part d'iris";
    }
  };

  const payementDossier = () => {
    if (user?.payementOk) {
      return "Le paiement a bien été effectué";
    } else {
      return "En attente de votre paiement";
    }
  };

  const choixEtablissement = () => {
    if (user?.etablissementOk) {
      return "L'établissment choisi est UNIVERSITE DE PARIS IV ";
    } else {
      return "En attente de confirmation de votre etablissement";
    }
  };

  const choixLogement = () => {
    if (user?.logementOK) {
      return "Le logement choisi se situe à 23 rue du massif centrale VILLEJUIF";
    } else {
      return "En attente de confirmation du choix de votre logement";
    }
  };

  const style = {
    "font-size": "17px",
    "font-weight": "500",
  };

  const getStyleMessage = (ok) => {
    if (ok) {
      return { color: "#078041", "font-size": "15px", "font-weight": "550" };
    } else {
      return { color: "#EB2815", "font-size": "15px", "font-weight": "550" };
    }
  };

  return (
    <div>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={style}>1 - Je saisis mon dossier</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <DossierUser user={user} ajoutPropertie={ajoutPropertie} />
        </AccordionDetails>
      </Accordion>
      <Accordion disabled={!user?.dossierOk}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography style={style}>2 - Iris vérifie mon dossier</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography
            variant="h10"
            style={getStyleMessage(user?.verificationDossierOk)}
          >
            {irisVerifieDossier()}
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion disabled={!user?.verificationDossierOk}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel3a-header"
        >
          <Typography style={style}>3 - Paiement</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant="h10" style={getStyleMessage(user?.payementOk)}>
            {payementDossier()}
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion disabled={!user?.payementOk}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel4a-header"
        >
          <Typography style={style}>4 - Etablissement choisi</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography
            variant="h10"
            style={getStyleMessage(user?.etablissementOk)}
          >
            {choixEtablissement()}
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion disabled={!user?.etablissementOk}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel3a-content"
          id="panel5a-header"
        >
          <Typography style={style}>5 - Logement choisi </Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant="h10" style={getStyleMessage(user?.logementOK)}>
            {choixLogement()}
          </Typography>
        </AccordionDetails>
      </Accordion>

      <Accordion disabled={!user?.logementOK}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel6a-content"
          id="panel5a-header"
        >
          <Typography style={style}>6 - Procedure VISA </Typography>
        </AccordionSummary>
      </Accordion>
    </div>
  );
};

export default InscriptionEtudeEtranger;
InscriptionEtudeEtranger.propTypes = {
  user: PropTypes.object,
};
