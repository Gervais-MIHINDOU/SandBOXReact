const EnumObjectNotif = {
  INFO: "info",
  URGENT: "urgent",
  WARNING: "warning",
  SUCESS: "sucess",
};
export default EnumObjectNotif;
