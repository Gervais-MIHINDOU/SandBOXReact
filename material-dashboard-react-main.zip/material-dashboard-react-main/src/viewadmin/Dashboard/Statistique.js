const Statistique = (users) => {

    u

    useEffect(() => {
        setNombreUtilisateurs(Object.keys(users).length);
        setNombreClientTotal(
          Object.keys(response).filter((id) => !response[id].client.isAdmin)
            .length
        );
        setNombreAdmin(
          Object.keys(response).filter((id) => response[id].client.isAdmin).length
        );
  
        setUserOfThisYears(
          Object.keys(response).filter(
            (id) =>
              !response[id].client.isAdmin &&
              new Date(new Date().getFullYear(), 0, 1).getTime() <
                new Date(response[id].client.dateInscription).getTime()
          ).length
        );
        setUserOfThisMonth(
          Object.keys(response).filter(
            (id) =>
              !response[id].client.isAdmin &&
              new Date(
                new Date().getFullYear(),
                new Date().getMonth(),
                0
              ).getTime() <
                new Date(response[id].client.dateInscription).getTime() &&
              new Date(response[id].client.dateInscription).getTime() <
                new Date(
                  new Date().getFullYear(),
                  new Date().getMonth() + 1,
                  0
                ).getTime()
          ).length
    }, []);



}