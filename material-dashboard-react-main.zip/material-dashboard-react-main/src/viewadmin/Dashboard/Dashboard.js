// @material-ui/core
import { makeStyles } from "@material-ui/core/styles";
import { PermIdentity, Policy } from "@material-ui/icons";
import Accessibility from "@material-ui/icons/Accessibility";
import AccessTime from "@material-ui/icons/AccessTime";
import ArrowUpward from "@material-ui/icons/ArrowUpward";
import Person from "@material-ui/icons/Person";
import styles from "assets/jss/material-dashboard-react/views/dashboardStyle.js";
import baseIris from "baseiris";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CustomTabs from "components/CustomTabs/CustomTabs.js";
import GridContainer from "components/Grid/GridContainer.js";
// core components
import GridItem from "components/Grid/GridItem.js";
import Tasks from "components/Tasks/Tasks.js";
import React, { useEffect, useState } from "react";
// react plugin for creating charts
import ChartistGraph from "react-chartist";
import {
  completedTasksChart,
  dailySalesChart,
  emailsSubscriptionChart,
} from "variables/charts.js";
import Calendrier from "./Calendrier";

const useStyles = makeStyles(styles);
const Dashboard = () => {
  const [mombreClientTotal, setNombreClientTotal] = useState(0);
  const [nombreUtilisateurs, setNombreUtilisateurs] = useState(0);
  const [nombreAdmin, setNombreAdmin] = useState(0);
  const [userOfThisYears, setUserOfThisYears] = useState(0);
  const [userOfThisMonth, setUserOfThisMonth] = useState();
  const [amountUnit, setAmountUnit] = useState(0);
  const [responseData, setResponseData] = useState({});

  const getAllAdmins = () => {
    return Object.keys(responseData)
      .filter((id) => responseData[id].client.isAdmin)
      .map((id) => {
        return {
          email: responseData[id].client.email,
          nom: responseData[id].client.nom,
          phone: responseData[id].client.phone,
          dateInscription: responseData[id].client.dateInscription,
          isActif: responseData[id].client.isActif,
          lastdateActif: responseData[id].client.lastdateActif,
          nbreAction: responseData[id].client.nbreAction,
        };
      });
  };

  const nbreClientAyantPayeCetteAnnee = () => {
    return Object.keys(responseData).filter(
      (id) =>
        !responseData[id].client.isAdmin &&
        responseData[id].client.payementOk &&
        new Date(new Date().getFullYear(), 0, 1).getTime() <
          new Date(responseData[id].client.dateInscription).getTime()
    ).length;
  };

  const nbreClientNayantpaspaye = () => {
    return Object.keys(responseData).filter(
      (id) =>
        !responseData[id].client.isAdmin && !responseData[id].client.payementOk
    ).length;
  };

  const nbreClientTotal = () => {
    return Object.keys(responseData).filter(
      (id) => !responseData[id].client.isAdmin
    ).length;
  };

  const nbreClientOfThisMonth = () => {
    return Object.keys(responseData).filter(
      (id) =>
        !responseData[id].client.isAdmin &&
        new Date(new Date().getFullYear(), new Date().getMonth(), 0).getTime() <
          new Date(responseData[id].client.dateInscription).getTime() &&
        new Date(responseData[id].client.dateInscription).getTime() <
          new Date(
            new Date().getFullYear(),
            new Date().getMonth() + 1,
            0
          ).getTime()
    ).length;
  };

  const nbreClientOfLastyearforThisMonth = () => {
    return Object.keys(responseData).filter(
      (id) =>
        !responseData[id].client.isAdmin &&
        new Date(
          new Date().getFullYear() - 1,
          new Date().getMonth(),
          0
        ).getTime() <
          new Date(responseData[id].client.dateInscription).getTime() &&
        new Date(responseData[id].client.dateInscription).getTime() <
          new Date(
            new Date().getFullYear() - 1,
            new Date().getMonth() + 1,
            0
          ).getTime()
    ).length;
  };

  const nbreClientByMonthDejaPaye = (response, nbreAnneeMoins, month) => {
    var a = Object.keys(response).filter(
      (id) =>
        !response[id].client.isAdmin &&
        response[id].client.payementOk &&
        new Date(
          new Date().getFullYear() - nbreAnneeMoins,
          month,
          0
        ).getTime() < new Date(response[id].client.dateInscription).getTime() &&
        new Date(response[id].client.dateInscription).getTime() <
          new Date(
            new Date().getFullYear() - nbreAnneeMoins,
            month + 1,
            0
          ).getTime()
    ).length;

    console.log(a);
    return a;
  };

  const nbreClientByMonth = (response, nbreAnneeMoins, month) => {
    return Object.keys(response).filter(
      (id) =>
        !response[id].client.isAdmin &&
        new Date(
          new Date().getFullYear() - nbreAnneeMoins,
          month,
          0
        ).getTime() < new Date(response[id].client.dateInscription).getTime() &&
        new Date(response[id].client.dateInscription).getTime() <
          new Date(
            new Date().getFullYear() - nbreAnneeMoins,
            month + 1,
            0
          ).getTime()
    ).length;
  };

  const nbreClientNayantPaspayeByMonth = (response, nbreAnneeMoins, month) => {
    return Object.keys(response).filter(
      (id) =>
        !response[id].client.isAdmin &&
        !response[id].client.payementOk &&
        new Date(
          new Date().getFullYear() - nbreAnneeMoins,
          month,
          0
        ).getTime() < new Date(response[id].client.dateInscription).getTime() &&
        new Date(response[id].client.dateInscription).getTime() <
          new Date(
            new Date().getFullYear() - nbreAnneeMoins,
            month + 1,
            0
          ).getTime()
    ).length;
  };

  const dataNbreClients = {
    labels: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
    series: [
      [
        nbreClientByMonth(responseData, 1, Calendrier.JAN),
        nbreClientByMonth(responseData, 1, Calendrier.FEV),
        nbreClientByMonth(responseData, 1, Calendrier.MAR),
        nbreClientByMonth(responseData, 1, Calendrier.AVR),
        nbreClientByMonth(responseData, 1, Calendrier.MAI),
        nbreClientByMonth(responseData, 1, Calendrier.JUI),
        nbreClientByMonth(responseData, 1, Calendrier.JUL),
        nbreClientByMonth(responseData, 1, Calendrier.AOU),
        nbreClientByMonth(responseData, 1, Calendrier.SEP),
        nbreClientByMonth(responseData, 1, Calendrier.OCT),
        nbreClientByMonth(responseData, 1, Calendrier.NOV),
        nbreClientByMonth(responseData, 1, Calendrier.DEC),
      ],
      [
        nbreClientByMonth(responseData, 0, Calendrier.JAN),
        nbreClientByMonth(responseData, 0, Calendrier.FEV),
        nbreClientByMonth(responseData, 0, Calendrier.MAR),
        nbreClientByMonth(responseData, 0, Calendrier.AVR),
        nbreClientByMonth(responseData, 0, Calendrier.MAI),
        nbreClientByMonth(responseData, 0, Calendrier.JUI),
        nbreClientByMonth(responseData, 0, Calendrier.JUL),
        nbreClientByMonth(responseData, 0, Calendrier.AOU),
        nbreClientByMonth(responseData, 0, Calendrier.SEP),
        nbreClientByMonth(responseData, 0, Calendrier.OCT),
        nbreClientByMonth(responseData, 0, Calendrier.NOV),
        nbreClientByMonth(responseData, 0, Calendrier.DEC),
      ],
    ],
  };

  const dataNbreClientsNayantPasPaye = {
    labels: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
    series: [
      [
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.JAN),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.FEV),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.MAR),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.AVR),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.MAI),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.JUI),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.JUL),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.AOU),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.SEP),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.OCT),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.NOV),
        nbreClientNayantPaspayeByMonth(responseData, 1, Calendrier.DEC),
      ],
      [
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.JAN),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.FEV),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.MAR),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.AVR),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.MAI),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.JUI),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.JUL),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.AOU),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.SEP),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.OCT),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.NOV),
        nbreClientNayantPaspayeByMonth(responseData, 0, Calendrier.DEC),
      ],
    ],
  };

  const dataMontantPerçu = {
    labels: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
    series: [
      [
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.JAN) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.FEV) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.MAR) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.AVR) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.MAI) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.JUI) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.JUL) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.AOU) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.SEP) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.OCT) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.NOV) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 0, Calendrier.DEC) * amountUnit,
      ],
      [
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.JAN) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.FEV) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.MAR) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.AVR) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.MAI) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.JUI) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.JUL) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.AOU) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.SEP) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.OCT) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.NOV) * amountUnit,
        nbreClientByMonthDejaPaye(responseData, 1, Calendrier.DEC) * amountUnit,
      ],
    ],
  };
  const pourcentage = (valA, valB) => {
    if (valB === 0) {
      return 100;
    }
    return (valA / valB - 1) * 100;
  };

  useEffect(() => {
    baseIris.fetch(`/`, {}).then((response) => {
      setResponseData({ ...responseData, ...response });
      setAmountUnit(150);
      setNombreUtilisateurs(Object.keys(response).length);
      setNombreClientTotal(
        Object.keys(response).filter((id) => !response[id].client.isAdmin)
          .length
      );
      setNombreAdmin(
        Object.keys(response).filter((id) => response[id].client.isAdmin).length
      );

      setUserOfThisYears(
        Object.keys(response).filter(
          (id) =>
            !response[id].client.isAdmin &&
            new Date(new Date().getFullYear(), 0, 1).getTime() <
              new Date(response[id].client.dateInscription).getTime()
        ).length
      );
      setUserOfThisMonth(
        Object.keys(response).filter(
          (id) =>
            !response[id].client.isAdmin &&
            new Date(
              new Date().getFullYear(),
              new Date().getMonth(),
              0
            ).getTime() <
              new Date(response[id].client.dateInscription).getTime() &&
            new Date(response[id].client.dateInscription).getTime() <
              new Date(
                new Date().getFullYear(),
                new Date().getMonth() + 1,
                0
              ).getTime()
        ).length
      );
      return response;
    });
  }, []);

  const classes = useStyles();
  return (
    <div>
      <GridContainer>
        <GridItem xs={12} sm={6} md={3}>
          <Card>
            <CardHeader color="info" stats icon>
              <CardIcon color="info">
                <Person />
              </CardIcon>
              <p className={classes.cardCategory}>Utilisateurs</p>
              <h3 className={classes.cardTitle}>{nombreUtilisateurs}</h3>
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <span>
                  {
                    "Nombre d'uilisateurs inscrit sur l'application (clients + admins)"
                  }
                </span>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={6} md={3}>
          <Card>
            <CardHeader color="success" stats icon>
              <CardIcon color="success">
                <PermIdentity />
              </CardIcon>
              <p className={classes.cardCategory}>Clients</p>
              <h3 className={classes.cardTitle}>{mombreClientTotal}</h3>
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <span>
                  {"Uniquement le nombre de clients inscrit sur l'application"}
                </span>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={6} md={3}>
          <Card>
            <CardHeader color="info" stats icon>
              <CardIcon color="info">
                <Policy />
              </CardIcon>
              <p className={classes.cardCategory}>Admins</p>
              <h3 className={classes.cardTitle}>{nombreAdmin}</h3>
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <span>
                  {"Le nombre d'administrateur présent sur l'application"}
                </span>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={6} md={3}>
          <Card>
            <CardHeader color="info" stats icon>
              <CardIcon color="info">
                <Accessibility />
              </CardIcon>
              <p className={classes.cardCategory}>Nouveau client</p>
              <br />
            </CardHeader>
            <CardFooter stats>
              <div className={classes.stats}>
                <span>
                  <h6 className={classes.cardTitle}>
                    {"+" + userOfThisYears} cette année
                  </h6>
                  <br />
                  <h6 className={classes.cardTitle}>
                    {"+" + userOfThisMonth} ce mois
                  </h6>
                </span>
              </div>
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
      <GridContainer>
        <GridItem xs={12} sm={12} md={4}>
          <Card chart>
            <CardHeader color="success">
              <ChartistGraph
                className="ct-chart"
                data={dataNbreClients}
                type="Line"
                options={dailySalesChart.options}
                listener={dailySalesChart.animation}
              />
            </CardHeader>
            <CardBody>
              <h4 className={classes.cardTitle}>
                Comparatif nombre de clients
              </h4>
              <p className={classes.cardCategory}>
                <span className={classes.successText}>
                  <ArrowUpward className={classes.upArrowCardCategory} />
                  {pourcentage(
                    nbreClientOfThisMonth(),
                    nbreClientOfLastyearforThisMonth()
                  )}
                  %
                </span>
                {" augmentation clients"}
              </p>
            </CardBody>
            <CardFooter chart>
              <div className={classes.stats}>
                <AccessTime />
                {
                  "comparaison entre le mois de cette année et le mois de l'année passé"
                }
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={12} md={4}>
          <Card chart>
            <CardHeader color="warning">
              <ChartistGraph
                className="ct-chart"
                data={dataNbreClientsNayantPasPaye}
                type="Bar"
                options={emailsSubscriptionChart.options}
                responsiveOptions={emailsSubscriptionChart.responsiveOptions}
                listener={emailsSubscriptionChart.animation}
              />
            </CardHeader>
            <CardBody>
              <h4 className={classes.cardTitle}>
                {"Clients N'ayant pas encore reglé"}
              </h4>
              <p className={classes.cardCategory}>
                {nbreClientTotal() !== 0
                  ? (nbreClientNayantpaspaye() / nbreClientTotal()) * 100
                  : 0}
                % {" d'augmentation des dus non reglés"}
              </p>
              <p className={classes.cardCategory}>
                {nbreClientNayantpaspaye() +
                  " client(s) n'ont(a) pas encore reglé "}
              </p>
            </CardBody>
            <CardFooter chart>
              <div className={classes.stats}>
                <AccessTime />
                {
                  "comparaison entre les clients ayant déja regler et les clienst n'ayant pas encore reglé"
                }
              </div>
            </CardFooter>
          </Card>
        </GridItem>
        <GridItem xs={12} sm={12} md={4}>
          <Card chart>
            <CardHeader color="danger">
              <ChartistGraph
                className="ct-chart"
                data={dataMontantPerçu}
                type="Line"
                options={completedTasksChart.options}
                listener={completedTasksChart.animation}
              />
            </CardHeader>
            <CardBody>
              <h4 className={classes.cardTitle}>Les montants perçu</h4>
              <p className={classes.cardCategory}>
                {nbreClientAyantPayeCetteAnnee() * amountUnit} euro cette année
              </p>
            </CardBody>
            <CardFooter chart>
              <div className={classes.stats}>
                <AccessTime /> Total des montants perçu cette année
              </div>
            </CardFooter>
          </Card>
        </GridItem>
      </GridContainer>
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <CustomTabs
            title=""
            headerColor="primary"
            tabs={[
              {
                tabName: "Admins",
                tabIcon: Policy,
                tabContent: (
                  <Tasks
                    tableHead={[
                      "nom",
                      "email",
                      "date d'inscription",
                      "dernière date actif",
                    ]}
                    checkedIndexes={[0, getAllAdmins().length]}
                    tasks={getAllAdmins()}
                  />
                ),
              },
            ]}
          />
        </GridItem>
      </GridContainer>
    </div>
  );
};

export default Dashboard;
