const Calendrier = {
  JAN: 0,
  FEV: 1,
  MAR: 2,
  AVR: 3,
  MAI: 4,
  JUI: 5,
  JUL: 6,
  AOU: 7,
  SEP: 8,
  OCT: 9,
  NOV: 10,
  DEC: 11,
};
export default Calendrier;
